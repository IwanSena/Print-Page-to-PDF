// --- FUNGSI MEMUAT TERJEMAHAN ---
function localizeHtml() {
  const elements = document.querySelectorAll('[data-i18n]');
  elements.forEach(el => {
    const key = el.getAttribute('data-i18n');
    const message = chrome.i18n.getMessage(key);
    if (message) {
      el.textContent = message;
    }
  });
}

// --- FUNGSI CETAK (Engine Utama) ---
function cetakHalaman(opsi) {
  const html = document.documentElement;
  const body = document.body;
  // Jika Satu Halaman, pakai scale 1 agar aman. Jika A4, pakai scale 2 agar HD.
  const canvasScale = opsi.satuHalamanPanjang ? 1 : 2;
  
  const pageHeight = Math.max( body.scrollHeight, body.offsetHeight, html.clientHeight, html.scrollHeight, html.offsetHeight );
  const pageWidth = Math.max( body.scrollWidth, body.offsetWidth, html.clientWidth, html.scrollWidth, html.offsetWidth );

  const element = document.body.cloneNode(true);
  
  if (opsi.modeBersih) {
    const elemenJahat = [
      'script', 'iframe', 'ins', 'nav', 'footer', 
      '.adsbygoogle', '[id*="iklan"]', '[class*="iklan"]',
      '[id*="ads"]', '[class*="ads"]', '[id*="advert"]',
      '[class*="advert"]', '[class*="sticky"]', '[class*="floating"]'
    ];
    element.querySelectorAll(elemenJahat.join(', ')).forEach(el => {
      if (el && typeof el.remove === 'function') {
        el.remove();
      }
    });
  }

  const pdfOptions = {
    margin:       [10, 5, 10, 5],
    filename:     `${opsi.filename}.pdf`,
    image:        { type: 'jpeg', quality: 0.95 },
    html2canvas:  { scale: canvasScale, useCORS: true, willReadFrequently: true }
  };

  if (opsi.satuHalamanPanjang) {
    pdfOptions.jsPDF = { unit: 'px', format: [pageWidth + 40, pageHeight + 40] };
  } else {
    pdfOptions.jsPDF = { unit: 'mm', format: opsi.paperSize, orientation: opsi.orientation };
  }
  
  return html2pdf().from(element).set(pdfOptions).save();
}

// --- LOGIKA TOMBOL ---
const cetakButton = document.getElementById('cetakButton');
const statusContainer = document.getElementById('status-container');
const statusText = document.getElementById('status-text');

function saveOptions() {
  const options = {
    filename: document.getElementById('filename').value,
    paperSize: document.getElementById('paper-size').value,
    orientation: document.getElementById('orientation').value,
    satuHalamanPanjang: document.getElementById('one-page').checked,
    modeBersih: document.getElementById('clean-mode').checked
  };
  chrome.storage.local.set({ savedOptions: options });
}

function loadOptions() {
  chrome.storage.local.get('savedOptions', (data) => {
    if (data.savedOptions) {
      document.getElementById('filename').value = data.savedOptions.filename || 'halaman-web';
      document.getElementById('paper-size').value = data.savedOptions.paperSize || 'a4';
      document.getElementById('orientation').value = data.savedOptions.orientation || 'portrait';
      document.getElementById('one-page').checked = data.savedOptions.satuHalamanPanjang || false;
      document.getElementById('clean-mode').checked = data.savedOptions.modeBersih !== undefined ? data.savedOptions.modeBersih : true;
    } else {
      document.getElementById('clean-mode').checked = true;
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  localizeHtml(); 
  loadOptions();
});

document.getElementById('filename').addEventListener('input', saveOptions);
document.getElementById('paper-size').addEventListener('change', saveOptions);
document.getElementById('orientation').addEventListener('change', saveOptions);
document.getElementById('one-page').addEventListener('change', saveOptions);
document.getElementById('clean-mode').addEventListener('change', saveOptions);

cetakButton.addEventListener('click', async () => {
  cetakButton.disabled = true;
  cetakButton.textContent = chrome.i18n.getMessage("statusLoading");
  statusContainer.classList.remove('hidden');
  statusText.textContent = '';
  statusText.className = 'status-message';

  saveOptions();

  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab || !tab.url) {
    showError(chrome.i18n.getMessage("statusErrorNoTab"));
    return;
  }
  if (tab.url.startsWith('chrome://') || tab.url.startsWith('file://')) {
    showError(chrome.i18n.getMessage("statusErrorInternalPage"));
    return;
  }
  
  const opsi = {
    filename: document.getElementById('filename').value || 'halaman-web',
    paperSize: document.getElementById('paper-size').value,
    orientation: document.getElementById('orientation').value,
    satuHalamanPanjang: document.getElementById('one-page').checked,
    modeBersih: document.getElementById('clean-mode').checked
  };

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['html2pdf.bundle.min.js']
    });

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: cetakHalaman,
      args: [opsi]
    });

    showSuccess(chrome.i18n.getMessage("statusSuccess"));

  } catch (e) {
    console.error(e);
    if (e.message && e.message.includes('14400')) {
      showError(chrome.i18n.getMessage("statusErrorTooLarge"));
    } else {
      showError(chrome.i18n.getMessage("statusErrorGeneral"));
    }
  }
});

function showSuccess(message) {
  statusText.textContent = message;
  statusText.className = 'status-message status-success';
  cetakButton.disabled = false;
  cetakButton.textContent = chrome.i18n.getMessage("buttonDownload");
  statusContainer.classList.add('hidden');
}

function showError(message) {
  statusText.textContent = message;
  statusText.className = 'status-message status-error';
  cetakButton.disabled = false;
  cetakButton.textContent = chrome.i18n.getMessage("buttonDownload");
  statusContainer.classList.add('hidden');
}